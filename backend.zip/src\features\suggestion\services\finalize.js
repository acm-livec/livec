import { AppError, SuggestionNotFoundError, NoUserWithIdError } from "../../../shared/errors/index.js";
import Suggestions from '../models/suggestions.model.js';
import EditorsInChief from '../../users/models/users/editor-in-chief/chiefs.model.js';
import baseLogger from '../../../../logger/logger.js';

const logger = baseLogger.addSource({
    file: 'suggestion.service',
    method: "associateEditorFinalized",
    params: ['suggestionId', 'author', 'markdownText']
});



const associateEditorFinalized = async (suggestionId, associateEditor, updatedSection) => {
    try {

        logger.debug("suggestion.finalize.db.searching", { suggestionId })

        const suggestionToFinalize = await Suggestions.findById(suggestionId)

        if (!suggestionToFinalize) {
            throw new SuggestionNotFoundError
        }
        logger.debug("suggestion.finalize.db.found")

        logger.debug("suggestion.finalize.starting")

        suggestionToFinalize.associateEditorFinalized(associateEditor, updatedSection)

        await Suggestions.update(suggestionToFinalize)
        logger.debug("suggestion.finalize.finished")

        const eic = suggestionToFinalize.assigned_editor_in_chief
        logger.debug("suggestion.finalize.notify.db.searching", { eic })
        const eicToNotify = await EditorsInChief.findById(eic)

        if (!eicToNotify) {
            throw new NoUserWithIdError
        }
        logger.debug("suggestion.finalize.notify.db.found")

        eicToNotify.assignSuggestion(suggestionId)

        await EditorsInChief.update(eicToNotify)



    } catch (error) {

        if (!(error instanceof AppError)) {
            logger.error(error.stack)
        } else {
            logger.warn(error.message, { err: error.errorCode })
        }

        throw error
    }
}






export default associateEditorFinalized;