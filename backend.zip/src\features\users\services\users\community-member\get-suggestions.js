import { AppError } from "../../../../../shared/errors/index.js";
import Suggestions from '../../../../suggestion/models/suggestions.model.js';
import { getUserNameById } from "../../../../../shared/utils/getUserNameById.js";
import baseLogger from '../../../../../../logger/logger.js';

const logger = baseLogger.addSource({
    file: 'community-member.service',
    method: "getAllCommunityMemberSuggestions",
    params: ['userId']
});


const getAllCommunityMemberSuggestions = async (userId) => {
    
    try {

        logger.debug(`cm.suggestions.get.db.searching`)
        const suggestions = await Suggestions.getByCommunityMemberId(userId)

        for (const suggestion of suggestions) {
            if (Array.isArray(suggestion.publicUpdates)) {
                for (const update of suggestion.publicUpdates) {
                    if (typeof update.author === 'string' && update.author !== 'LiveC') {
                        update.author = await getUserNameById(update.author)
                    }
                }
            }
        }

        return suggestions

    } catch (error) {

        if (!(error instanceof AppError)) {
            logger.error(error.stack)
        } else {
            logger.warn(error.message, { err: error.errorCode })
        }

        throw error
    }
}

export default getAllCommunityMemberSuggestions;